package com.ouyang.springbootlibrarymanagement.shiro;

import com.ouyang.springbootlibrarymanagement.modules.sys.entity.SysPermissions;
import com.ouyang.springbootlibrarymanagement.modules.sys.entity.SysRoleEntity;
import com.ouyang.springbootlibrarymanagement.modules.sys.entity.SysUserEntity;
import com.ouyang.springbootlibrarymanagement.modules.sys.service.ISysPermissionsService;
import com.ouyang.springbootlibrarymanagement.modules.sys.service.ISysRoleService;
import com.ouyang.springbootlibrarymanagement.modules.sys.service.ISysUserService;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class CustomRealm extends AuthorizingRealm {
    @Autowired
    private ISysUserService sysUserService;
    @Autowired
    private ISysRoleService sysRoleService;
    @Autowired
    private ISysPermissionsService sysPermissionsService;

    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        //实现权限认证，通过服务加载用户角色和权限信息设置进去
        String username = (String) principalCollection.getPrimaryPrincipal();
        SysUserEntity user = sysUserService.getUserByUsername(username);
        if (user != null) {
            SimpleAuthorizationInfo simpleAuthorizationInfo = new SimpleAuthorizationInfo();
            List<SysRoleEntity> roleList = sysRoleService.getRolesByUser(user);
            for (SysRoleEntity role : roleList) {
                simpleAuthorizationInfo.addRole(role.getRoleName());
                List<SysPermissions> permissionsList = sysPermissionsService.getPermissionsByRole(role);
                for (SysPermissions permissions : permissionsList) {
                    simpleAuthorizationInfo.addStringPermission(permissions.getPermissionsName());
                }
            }
            return simpleAuthorizationInfo;
        }
        return null;
    }

    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {
        //实现用户认证
        if (authenticationToken.getPrincipal() == null){
            return null;
        }
        String username = authenticationToken.getPrincipal().toString();
        SysUserEntity user = sysUserService.getUserByUsername(username);
        if (user == null){
            return null;
        }else {
            SimpleAuthenticationInfo simpleAuthorizationInfo = new SimpleAuthenticationInfo(username,user.getPassword(),getName());
            return simpleAuthorizationInfo;
        }
    }
}

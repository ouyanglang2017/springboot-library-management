package com.ouyang.springbootlibrarymanagement.modules.sys.controller;

import com.ouyang.springbootlibrarymanagement.common.api.Result;
import com.ouyang.springbootlibrarymanagement.common.utils.PasswordUtil;
import com.ouyang.springbootlibrarymanagement.common.utils.oConvertUtils;
import com.ouyang.springbootlibrarymanagement.modules.sys.entity.SysUserEntity;
import com.ouyang.springbootlibrarymanagement.modules.sys.mapper.SysUserMapper;
import com.ouyang.springbootlibrarymanagement.modules.sys.service.ISysUserService;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.AuthorizationException;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

@RestController
@RequestMapping("sys/user")
public class SysUserController {
    @Autowired
    SysUserMapper sysUserMapper;
    @Autowired
    private ISysUserService sysUserService;

    @RequestMapping("/add")
    public Result<SysUserEntity> addUser() {
        Result<SysUserEntity> result = new Result<>();
        SysUserEntity sysUserEntity = new SysUserEntity();
        sysUserEntity.setUsername("admin");
        sysUserEntity.setPassword("admin");
        sysUserEntity.setCreateTime(new Date());
        sysUserEntity.setUpdateTime(new Date());
        String salt = oConvertUtils.randomGen(8);
        sysUserEntity.setSalt(salt);
        sysUserEntity.setStatus(1);
        String passwordEncode = PasswordUtil.encrypt(sysUserEntity.getUsername(), sysUserEntity.getPassword(), salt);
        sysUserEntity.setPassword(passwordEncode);
        sysUserMapper.insert(sysUserEntity);
        result.success("添加成功");
        result.setResult(sysUserEntity);
        return result;
    }

    @RequestMapping("/login")
    public Result<SysUserEntity> login() {
        Result<SysUserEntity> result = new Result<>();
        SysUserEntity sysUserEntity = new SysUserEntity();
        sysUserEntity.setPassword("admin");
        sysUserEntity.setUsername("admin");
        SysUserEntity user = sysUserService.getUserByUsername("admin");
        String salt = user.getSalt();
        String passwordEncode = PasswordUtil.encrypt(sysUserEntity.getUsername(), sysUserEntity.getPassword(), salt);
        Subject subject = SecurityUtils.getSubject();
        UsernamePasswordToken usernamePasswordToken = new UsernamePasswordToken("admin",passwordEncode);
        try{
            subject.login(usernamePasswordToken);
        }catch (AuthenticationException e){
            result.error500("账号或密码错误");
            return result;
        }catch (AuthorizationException e){
            result.error500("没有权限");
            return result;
        }
        result.success("登录成功");
        return result;
    }
}

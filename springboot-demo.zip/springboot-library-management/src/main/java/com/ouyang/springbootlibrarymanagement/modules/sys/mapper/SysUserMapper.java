package com.ouyang.springbootlibrarymanagement.modules.sys.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.ouyang.springbootlibrarymanagement.modules.sys.entity.SysUserEntity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SysUserMapper extends BaseMapper<SysUserEntity> {

}
